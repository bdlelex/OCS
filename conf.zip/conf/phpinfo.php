<?php
	/**
	* Modificado por: Robson Vaamonde
	* Site: www.procedimentosemti.com.br
	* Facebook: facebook.com/ProcedimentosEmTI
	* Facebook: facebook.com/BoraParaPratica
	* YouTube: youtube.com/BoraParaPratica
	* Data de criação: 04/11/2018
	* Data de atualização: 20/03/2021
	* Versão: 0.04
	* Testado e homologado para a versão do Ubuntu Server 18.04.x LTS x64
	* Kernel >= 4.15.x
	*/

	/** Mostra muitas informações sobre a configuração PHP e do Apache*/
	phpinfo(); 
?>